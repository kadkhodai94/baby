package com.lalenawid.kidsalphabet;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends Activity {
    private final LetterItem[] items = new LetterItem[]{
            new LetterItem("ا", "انار", "🍎", R.raw.audio_anar),
            new LetterItem("ب", "بادکنک", "🎈", R.raw.audio_badkonak),
            new LetterItem("پ", "پروانه", "🦋", R.raw.audio_parvane),
            new LetterItem("ت", "توپ", "⚽", R.raw.audio_toop),
            new LetterItem("م", "ماهی", "🐟", R.raw.audio_mahi)
    };

    private SharedPreferences prefs;
    private MediaPlayer player;
    private int score = 0;
    private int selectedColor = Color.rgb(24, 179, 128);
    private final Random random = new Random();

    private static final int CREAM = Color.rgb(255, 245, 225);
    private static final int CREAM_2 = Color.rgb(255, 251, 242);
    private static final int BLUE = Color.rgb(48, 111, 210);
    private static final int SKY = Color.rgb(67, 172, 232);
    private static final int GREEN = Color.rgb(24, 179, 128);
    private static final int ORANGE = Color.rgb(244, 152, 55);
    private static final int YELLOW = Color.rgb(255, 204, 67);
    private static final int PINK = Color.rgb(235, 68, 124);
    private static final int PURPLE = Color.rgb(143, 84, 255);
    private static final int INK = Color.rgb(42, 58, 94);
    private static final int MUTED = Color.rgb(108, 119, 143);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("progress", MODE_PRIVATE);
        score = prefs.getInt("score", 0);
        showSplash();
    }

    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        return g;
    }

    private GradientDrawable strokeBg(int color, int stroke, int strokeColor, float radius) {
        GradientDrawable g = rounded(color, radius);
        g.setStroke(dp(stroke), strokeColor);
        return g;
    }

    private GradientDrawable gradient(int start, int end, float radius) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{start, end});
        g.setCornerRadius(dp(radius));
        return g;
    }

    private GradientDrawable gradientV(int start, int end, float radius) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{start, end});
        g.setCornerRadius(dp(radius));
        return g;
    }

    private TextView text(String text, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT, style);
        v.setIncludeFontPadding(true);
        v.setTextDirection(View.TEXT_DIRECTION_RTL);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        v.setPadding(dp(8), dp(8), dp(8), dp(8));
        return v;
    }

    private TextView emojiText(String value, int sp) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(sp);
        v.setGravity(Gravity.CENTER);
        v.setIncludeFontPadding(false);
        v.setPadding(0, 0, 0, 0);
        v.setTextDirection(View.TEXT_DIRECTION_LTR);
        v.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        return v;
    }

    private TextView pill(String text, int color) {
        TextView b = text(text, 20, Color.WHITE, Typeface.BOLD);
        b.setMinHeight(dp(68));
        b.setBackground(gradient(color, lighten(color), 24));
        b.setElevation(dp(5));
        b.setClickable(true);
        b.setFocusable(true);
        b.setPadding(dp(18), dp(12), dp(18), dp(12));
        return b;
    }

    private int lighten(int color) {
        int r = Math.min(255, Color.red(color) + 26);
        int g = Math.min(255, Color.green(color) + 26);
        int b = Math.min(255, Color.blue(color) + 26);
        return Color.rgb(r, g, b);
    }

    private LinearLayout page() {
        LinearLayout bg = new LinearLayout(this);
        bg.setOrientation(LinearLayout.VERTICAL);
        bg.setGravity(Gravity.CENTER_HORIZONTAL);
        bg.setPadding(dp(18), dp(22), dp(18), dp(22));
        bg.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        bg.setBackgroundColor(CREAM);
        return bg;
    }

    private LinearLayout splashPage() {
        LinearLayout bg = page();
        bg.setBackground(gradientV(Color.rgb(255, 248, 232), Color.rgb(255, 236, 197), 0));
        return bg;
    }

    private void setPage(LinearLayout content) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.setBackgroundColor(CREAM);
        sv.addView(content, new ScrollView.LayoutParams(-1, -2));
        setContentView(sv);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(strokeBg(Color.rgb(255, 253, 248), 1, Color.rgb(245, 226, 188), 30));
        c.setElevation(dp(8));
        c.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return c;
    }

    private void add(ViewGroup parent, View child, int w, int h, int mt) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.setMargins(0, dp(mt), 0, 0);
        parent.addView(child, lp);
    }

    private FrameLayout imageBox(String emoji, int emojiSize, int bgColor) {
        FrameLayout box = new FrameLayout(this);
        box.setBackground(strokeBg(bgColor, 1, Color.rgb(244, 229, 199), 22));
        box.setPadding(dp(6), dp(6), dp(6), dp(6));
        TextView img = emojiText(emoji, emojiSize);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -1);
        lp.gravity = Gravity.CENTER;
        box.addView(img, lp);
        return box;
    }

    private TextView smallTile(String value, int color) {
        TextView t = text(value, 22, Color.WHITE, Typeface.BOLD);
        t.setBackground(gradient(color, lighten(color), 18));
        t.setElevation(dp(3));
        return t;
    }

    private LinearLayout feature(String icon, String title, int color) {
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setGravity(Gravity.CENTER);
        f.setPadding(dp(8), dp(8), dp(8), dp(8));
        f.setBackground(strokeBg(Color.WHITE, 1, Color.rgb(246, 226, 190), 22));
        f.setElevation(dp(3));
        add(f, emojiText(icon, 26), -1, dp(34), 0);
        TextView t = text(title, 14, color, Typeface.BOLD);
        t.setPadding(0, 0, 0, 0);
        add(f, t, -1, -2, 2);
        return f;
    }

    private void showSplash() {
        LinearLayout r = splashPage();

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        String[] tiles = {"ا", "ب", "پ", "ت"};
        int[] tileColors = {PINK, BLUE, GREEN, ORANGE};
        for (int i = 0; i < tiles.length; i++) {
            TextView tile = smallTile(tiles[i], tileColors[i]);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(56), dp(56));
            lp.setMargins(dp(4), 0, dp(4), 0);
            top.addView(tile, lp);
        }
        add(r, top, -1, -2, 14);

        LinearLayout hero = card();
        hero.setPadding(dp(18), dp(20), dp(18), dp(20));
        hero.setBackground(strokeBg(Color.rgb(255, 254, 250), 2, Color.rgb(255, 221, 156), 34));

        TextView badge = text("🌟  بازی و یادگیری فارسی", 17, ORANGE, Typeface.BOLD);
        badge.setBackground(strokeBg(Color.rgb(255, 249, 225), 1, Color.rgb(255, 223, 142), 22));
        badge.setPadding(dp(12), dp(8), dp(12), dp(8));
        add(hero, badge, -1, -2, 0);

        TextView mascot = emojiText("🧸", 86);
        add(hero, mascot, -1, dp(104), 12);

        TextView title = text("سلام کوچولو!", 31, INK, Typeface.BOLD);
        TextView sub = text("حرف‌ها منتظر تو هستند؛ ببین، گوش کن، رنگ کن و ستاره بگیر", 16, MUTED, Typeface.BOLD);
        add(hero, title, -1, -2, 2);
        add(hero, sub, -1, -2, 2);

        LinearLayout features = new LinearLayout(this);
        features.setOrientation(LinearLayout.HORIZONTAL);
        features.setGravity(Gravity.CENTER);
        features.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(0, dp(82), 1f);
        flp.setMargins(dp(4), 0, dp(4), 0);
        features.addView(feature("👂", "گوش کن", BLUE), flp);
        LinearLayout.LayoutParams flp2 = new LinearLayout.LayoutParams(0, dp(82), 1f);
        flp2.setMargins(dp(4), 0, dp(4), 0);
        features.addView(feature("🎨", "رنگ کن", PINK), flp2);
        LinearLayout.LayoutParams flp3 = new LinearLayout.LayoutParams(0, dp(82), 1f);
        flp3.setMargins(dp(4), 0, dp(4), 0);
        features.addView(feature("⭐", "جایزه", ORANGE), flp3);
        add(hero, features, -1, -2, 16);

        add(r, hero, -1, -2, 18);

        TextView start = pill("بزن بریم  🚀", GREEN);
        start.setTextSize(22);
        start.setOnClickListener(v -> showMenu());
        add(r, start, -1, dp(76), 22);

        TextView note = text("نسخه نمونه پروژه دانشجویی", 14, MUTED, Typeface.BOLD);
        add(r, note, -1, -2, 8);
        setPage(r);
        ObjectAnimator.ofFloat(mascot, "translationY", 0f, -14f, 0f).setDuration(1400).start();
    }

    private LinearLayout header(String title) {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(dp(14), dp(10), dp(14), dp(10));
        h.setBackground(strokeBg(Color.rgb(255, 253, 248), 1, Color.rgb(245, 226, 188), 24));
        h.setElevation(dp(3));
        h.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView scoreTv = text("⭐ " + score, 18, ORANGE, Typeface.BOLD);
        TextView titleTv = text(title, 21, INK, Typeface.BOLD);
        h.addView(titleTv, new LinearLayout.LayoutParams(0, -2, 1));
        h.addView(scoreTv, new LinearLayout.LayoutParams(dp(92), -2));
        return h;
    }

    private void showMenu() {
        LinearLayout r = page();
        add(r, header("خانه آموزش"), -1, -2, 10);

        LinearLayout welcome = card();
        add(welcome, emojiText("🎒", 54), -1, dp(64), 0);
        add(welcome, text("امروز چه چیزی یاد بگیریم؟", 25, BLUE, Typeface.BOLD), -1, -2, 4);
        add(welcome, text("یکی از بخش‌ها را انتخاب کن", 16, MUTED, Typeface.BOLD), -1, -2, 2);
        add(r, welcome, -1, -2, 26);

        TextView letters = pill("📚  آموزش حروف", BLUE);
        TextView quiz = pill("🧩  آزمون ساده", GREEN);
        TextView reset = pill("🔄  ریست امتیاز", ORANGE);
        letters.setOnClickListener(v -> showLetters());
        quiz.setOnClickListener(v -> showQuiz());
        reset.setOnClickListener(v -> { score = 0; prefs.edit().putInt("score", 0).apply(); showMenu(); });
        add(r, letters, -1, dp(76), 18);
        add(r, quiz, -1, dp(76), 14);
        add(r, reset, -1, dp(72), 14);
        setPage(r);
    }

    private void showLetters() {
        LinearLayout r = page();
        add(r, header("انتخاب حرف"), -1, -2, 10);
        add(r, text("روی یک کارت بزن تا حرف را یاد بگیری", 18, MUTED, Typeface.BOLD), -1, -2, 18);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setUseDefaultMargins(false);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for (LetterItem item : items) {
            LinearLayout c = letterCard(item);
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0;
            gp.height = dp(184);
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(dp(6), dp(7), dp(6), dp(7));
            grid.addView(c, gp);
        }
        add(r, grid, -1, -2, 10);
        TextView back = pill("بازگشت", ORANGE);
        back.setOnClickListener(v -> showMenu());
        add(r, back, -1, dp(68), 18);
        setPage(r);
    }

    private LinearLayout letterCard(LetterItem item) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setPadding(dp(10), dp(10), dp(10), dp(10));
        c.setBackground(strokeBg(Color.WHITE, 1, Color.rgb(231, 216, 185), 28));
        c.setElevation(dp(6));
        c.setClickable(true);
        c.setOnClickListener(v -> showLetter(item));

        TextView l = text(item.letter, 40, PINK, Typeface.BOLD);
        l.setPadding(0, 0, 0, 0);
        c.addView(l, new LinearLayout.LayoutParams(-1, dp(52)));

        FrameLayout image = imageBox(item.emoji, 44, Color.rgb(255, 250, 238));
        LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(-1, dp(74));
        imageLp.setMargins(0, dp(4), 0, dp(4));
        c.addView(image, imageLp);

        TextView w = text(item.word, 18, BLUE, Typeface.BOLD);
        w.setPadding(0, 0, 0, 0);
        c.addView(w, new LinearLayout.LayoutParams(-1, dp(34)));
        return c;
    }

    private void showLetter(LetterItem item) {
        LinearLayout r = page();
        add(r, header("آموزش حرف"), -1, -2, 10);

        LinearLayout c = card();
        TextView big = text(item.letter, 96, PINK, Typeface.BOLD);
        big.setPadding(0, 0, 0, 0);
        add(c, big, -1, dp(126), 0);

        FrameLayout imgPanel = imageBox(item.emoji, 70, Color.rgb(255, 250, 238));
        add(c, imgPanel, -1, dp(124), 4);

        TextView word = text(item.word, 35, BLUE, Typeface.BOLD);
        add(c, word, -1, -2, 4);
        TextView desc = text("حرف «" + item.letter + "» مثل «" + item.word + "»", 19, MUTED, Typeface.BOLD);
        add(c, desc, -1, -2, 0);
        add(r, c, -1, -2, 18);

        TextView sound = pill("🔊 تلفظ را گوش کن", BLUE);
        TextView color = pill("🎨 رنگ‌آمیزی حرف", GREEN);
        TextView back = pill("بازگشت", ORANGE);
        sound.setOnClickListener(v -> play(item.audioRes));
        color.setOnClickListener(v -> showColoring(item));
        back.setOnClickListener(v -> showLetters());
        add(r, sound, -1, dp(72), 18);
        add(r, color, -1, dp(72), 12);
        add(r, back, -1, dp(68), 12);
        setPage(r);
        ObjectAnimator.ofFloat(big, "scaleX", .4f, 1f).setDuration(450).start();
        ObjectAnimator.ofFloat(big, "scaleY", .4f, 1f).setDuration(450).start();
    }

    private void showColoring(LetterItem item) {
        LinearLayout r = page();
        add(r, header("رنگ‌آمیزی"), -1, -2, 10);
        add(r, text("با انگشت روی حرف رنگ بکش", 20, BLUE, Typeface.BOLD), -1, -2, 14);
        ColoringView cv = new ColoringView(this, item.letter);
        add(r, cv, -1, dp(430), 12);

        LinearLayout colors = new LinearLayout(this);
        colors.setGravity(Gravity.CENTER);
        colors.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        int[] cs = {Color.rgb(235,68,124), Color.rgb(48,111,210), Color.rgb(24,179,128), Color.rgb(143,84,255), Color.rgb(244,152,55)};
        for (int c : cs) {
            TextView cb = text("●", 34, c, Typeface.BOLD);
            cb.setBackground(strokeBg(Color.WHITE, 1, Color.rgb(236,220,190), 18));
            cb.setOnClickListener(v -> { selectedColor = c; cv.setPaintColor(c); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(58), dp(58));
            lp.setMargins(dp(4), 0, dp(4), 0);
            colors.addView(cb, lp);
        }
        add(r, colors, -1, -2, 12);
        TextView done = pill("تمام شد ⭐", GREEN);
        done.setOnClickListener(v -> {
            addScore(1);
            play(R.raw.audio_afarin);
            Toast.makeText(this, "آفرین!", Toast.LENGTH_SHORT).show();
            showLetter(item);
        });
        add(r, done, -1, dp(70), 14);
        setPage(r);
    }

    private void showQuiz() {
        LetterItem answer = items[random.nextInt(items.length)];
        LinearLayout r = page();
        add(r, header("آزمون ساده"), -1, -2, 10);

        LinearLayout c = card();
        FrameLayout imgPanel = imageBox(answer.emoji, 66, Color.rgb(255, 250, 238));
        add(c, imgPanel, -1, dp(120), 0);
        add(c, text("حرف اول کلمه «" + answer.word + "» کدام است؟", 22, INK, Typeface.BOLD), -1, -2, 8);
        add(c, text("گزینه درست را لمس کن", 16, MUTED, Typeface.NORMAL), -1, -2, 2);
        add(r, c, -1, -2, 18);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for (LetterItem item : items) {
            TextView opt = text(item.letter, 38, Color.WHITE, Typeface.BOLD);
            opt.setBackground(gradient(BLUE, lighten(BLUE), 22));
            opt.setElevation(dp(4));
            opt.setGravity(Gravity.CENTER);
            opt.setOnClickListener(v -> {
                if (item.letter.equals(answer.letter)) {
                    addScore(2);
                    play(R.raw.audio_afarin);
                    Toast.makeText(this, "درست بود ⭐", Toast.LENGTH_SHORT).show();
                    new Handler(Looper.getMainLooper()).postDelayed(this::showQuiz, 450);
                } else {
                    play(R.raw.audio_try_again);
                    Toast.makeText(this, "دوباره تلاش کن", Toast.LENGTH_SHORT).show();
                }
            });
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = 0;
            gp.height = dp(76);
            gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
            gp.setMargins(dp(6), dp(6), dp(6), dp(6));
            grid.addView(opt, gp);
        }
        add(r, grid, -1, -2, 14);
        TextView back = pill("بازگشت", ORANGE);
        back.setOnClickListener(v -> showMenu());
        add(r, back, -1, dp(68), 16);
        setPage(r);
    }

    private void play(int resId) {
        try {
            if (player != null) {
                player.stop();
                player.release();
            }
            player = MediaPlayer.create(this, resId);
            if (player == null) {
                Toast.makeText(this, "صدا روی این دستگاه اجرا نشد", Toast.LENGTH_SHORT).show();
                return;
            }
            player.setOnCompletionListener(mp -> {
                mp.release();
                if (player == mp) player = null;
            });
            player.start();
        } catch (Exception e) {
            Toast.makeText(this, "خطا در پخش صدا", Toast.LENGTH_SHORT).show();
        }
    }

    private void addScore(int n) {
        score += n;
        prefs.edit().putInt("score", score).apply();
    }

    @Override protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }

    static class LetterItem {
        String letter, word, emoji;
        int audioRes;
        LetterItem(String l, String w, String e, int a) { letter = l; word = w; emoji = e; audioRes = a; }
    }

    class ColoringView extends View {
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint drawPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint borderPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        String letter;
        float lastX, lastY;
        java.util.ArrayList<float[]> lines = new java.util.ArrayList<>();
        java.util.ArrayList<Integer> colors = new java.util.ArrayList<>();
        RectF rect = new RectF();
        Path clip = new Path();

        ColoringView(Context c, String l) {
            super(c); letter = l;
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            textPaint.setColor(Color.rgb(230, 232, 238));
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(dp(250));
            textPaint.setTypeface(Typeface.DEFAULT_BOLD);
            drawPaint.setColor(selectedColor);
            drawPaint.setStrokeWidth(dp(22));
            drawPaint.setStrokeCap(Paint.Cap.ROUND);
            drawPaint.setStrokeJoin(Paint.Join.ROUND);
            borderPaint.setStyle(Paint.Style.STROKE);
            borderPaint.setStrokeWidth(dp(2));
            borderPaint.setColor(Color.rgb(236, 220, 190));
        }
        void setPaintColor(int c) { drawPaint.setColor(c); }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            rect.set(dp(4), dp(4), getWidth() - dp(4), getHeight() - dp(4));
            clip.reset();
            clip.addRoundRect(rect, dp(30), dp(30), Path.Direction.CW);
            canvas.save();
            canvas.clipPath(clip);
            canvas.drawColor(Color.WHITE);
            canvas.drawText(letter, getWidth()/2f, getHeight()/2f + dp(88), textPaint);
            Paint p = new Paint(drawPaint);
            for (int i=0; i<lines.size(); i++) {
                p.setColor(colors.get(i));
                float[] a = lines.get(i);
                canvas.drawLine(a[0], a[1], a[2], a[3], p);
            }
            canvas.restore();
            canvas.drawRoundRect(rect, dp(30), dp(30), borderPaint);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction()==MotionEvent.ACTION_DOWN) { lastX=e.getX(); lastY=e.getY(); return true; }
            if (e.getAction()==MotionEvent.ACTION_MOVE) {
                lines.add(new float[]{lastX,lastY,e.getX(),e.getY()});
                colors.add(drawPaint.getColor());
                lastX=e.getX(); lastY=e.getY(); invalidate(); return true;
            }
            return true;
        }
    }
}
