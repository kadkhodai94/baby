package com.lalenawid.kidsalphabet;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private final LetterItem[] items = new LetterItem[]{
            new LetterItem("ا", "انار", "🍎"),
            new LetterItem("ب", "بادکنک", "🎈"),
            new LetterItem("پ", "پروانه", "🦋"),
            new LetterItem("ت", "توپ", "⚽"),
            new LetterItem("م", "ماهی", "🐟")
    };
    private TextToSpeech tts;
    private SharedPreferences prefs;
    private int score = 0;
    private int selectedColor = Color.rgb(76, 175, 80);
    private final Random random = new Random();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("progress", MODE_PRIVATE);
        score = prefs.getInt("score", 0);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("fa", "IR"));
        });
        showSplash();
    }

    private TextView tv(String text, int sp, int color, int style) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(null, style);
        v.setPadding(12, 10, 12, 10);
        return v;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(20);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(33, 150, 243));
        b.setPadding(16, 14, 16, 14);
        return b;
    }

    private LinearLayout root() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setGravity(Gravity.CENTER);
        r.setPadding(24, 30, 24, 24);
        r.setBackgroundColor(Color.rgb(255, 243, 217));
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return r;
    }

    private void add(ViewGroup parent, View child, int w, int h, int mt) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.setMargins(0, mt, 0, 0);
        parent.addView(child, lp);
    }

    private void showSplash() {
        LinearLayout r = root();
        TextView icon = tv("🌈", 76, Color.BLACK, 1);
        TextView title = tv("الفبای کودک", 34, Color.rgb(45, 85, 155), 1);
        TextView sub = tv("یادگیری حروف فارسی با بازی و رنگ‌آمیزی", 18, Color.DKGRAY, 0);
        Button start = btn("شروع یادگیری");
        start.setOnClickListener(v -> showMenu());
        add(r, icon, -1, -2, 0);
        add(r, title, -1, -2, 8);
        add(r, sub, -1, -2, 8);
        add(r, start, -1, 90, 32);
        setContentView(r);
        ObjectAnimator.ofFloat(icon, "rotation", -8f, 8f, -8f).setDuration(1200).start();
    }

    private void showMenu() {
        LinearLayout r = root();
        add(r, tv("امتیاز: " + score + " ⭐", 22, Color.rgb(230, 126, 34), 1), -1, -2, 0);
        add(r, tv("یکی از بخش‌ها را انتخاب کن", 24, Color.rgb(45, 85, 155), 1), -1, -2, 12);
        Button letters = btn("آموزش حروف");
        Button quiz = btn("آزمون ساده");
        Button reset = btn("ریست امتیاز");
        letters.setOnClickListener(v -> showLetters());
        quiz.setOnClickListener(v -> showQuiz());
        reset.setOnClickListener(v -> { score = 0; prefs.edit().putInt("score", 0).apply(); showMenu(); });
        add(r, letters, -1, 90, 24);
        add(r, quiz, -1, 90, 14);
        add(r, reset, -1, 80, 14);
        setContentView(r);
    }

    private void showLetters() {
        LinearLayout r = root();
        add(r, tv("انتخاب حرف", 28, Color.rgb(45, 85, 155), 1), -1, -2, 0);
        for (LetterItem item : items) {
            Button b = btn(item.letter + "  مثل  " + item.word + "  " + item.emoji);
            b.setTextSize(26);
            b.setBackgroundColor(Color.rgb(76, 175, 80));
            b.setOnClickListener(v -> showLetter(item));
            add(r, b, -1, 90, 12);
        }
        Button back = btn("بازگشت");
        back.setOnClickListener(v -> showMenu());
        add(r, back, -1, 80, 18);
        setContentView(r);
    }

    private void showLetter(LetterItem item) {
        LinearLayout r = root();
        TextView big = tv(item.letter, 92, Color.rgb(233, 30, 99), 1);
        TextView img = tv(item.emoji, 68, Color.BLACK, 0);
        TextView word = tv(item.word, 34, Color.rgb(45, 85, 155), 1);
        Button sound = btn("گوش کن 🔊");
        Button color = btn("رنگ‌آمیزی حرف 🎨");
        Button back = btn("بازگشت");
        sound.setOnClickListener(v -> speak(item.letter + ". " + item.word));
        color.setOnClickListener(v -> showColoring(item));
        back.setOnClickListener(v -> showLetters());
        add(r, big, -1, -2, 0);
        add(r, img, -1, -2, 8);
        add(r, word, -1, -2, 4);
        add(r, sound, -1, 80, 16);
        add(r, color, -1, 80, 12);
        add(r, back, -1, 76, 12);
        setContentView(r);
        ObjectAnimator.ofFloat(big, "scaleX", .2f, 1f).setDuration(500).start();
        ObjectAnimator.ofFloat(big, "scaleY", .2f, 1f).setDuration(500).start();
    }

    private void showColoring(LetterItem item) {
        LinearLayout r = root();
        add(r, tv("با انگشت رنگ کن: " + item.letter, 24, Color.rgb(45, 85, 155), 1), -1, -2, 0);
        ColoringView cv = new ColoringView(this, item.letter);
        add(r, cv, -1, 520, 12);
        LinearLayout colors = new LinearLayout(this);
        colors.setGravity(Gravity.CENTER);
        int[] cs = {Color.RED, Color.BLUE, Color.rgb(76,175,80), Color.MAGENTA, Color.rgb(255,152,0)};
        for (int c : cs) {
            Button cb = new Button(this); cb.setText(" "); cb.setBackgroundColor(c);
            cb.setOnClickListener(v -> { selectedColor = c; cv.setPaintColor(c); });
            colors.addView(cb, new LinearLayout.LayoutParams(90, 70));
        }
        add(r, colors, -1, -2, 10);
        Button done = btn("تمام شد ⭐");
        done.setOnClickListener(v -> { addScore(1); Toast.makeText(this, "آفرین!", Toast.LENGTH_SHORT).show(); showLetter(item); });
        add(r, done, -1, 80, 12);
        setContentView(r);
    }

    private void showQuiz() {
        LetterItem answer = items[random.nextInt(items.length)];
        LinearLayout r = root();
        add(r, tv("آزمون ساده", 28, Color.rgb(45, 85, 155), 1), -1, -2, 0);
        add(r, tv("کدام حرف اول کلمه «" + answer.word + "» است؟ " + answer.emoji, 23, Color.DKGRAY, 1), -1, -2, 18);
        for (LetterItem item : items) {
            Button b = btn(item.letter);
            b.setTextSize(36);
            b.setBackgroundColor(Color.rgb(33, 150, 243));
            b.setOnClickListener(v -> {
                if (item.letter.equals(answer.letter)) {
                    addScore(2);
                    speak("آفرین");
                    Toast.makeText(this, "درست بود ⭐", Toast.LENGTH_SHORT).show();
                    showQuiz();
                } else {
                    speak("دوباره تلاش کن");
                    Toast.makeText(this, "دوباره تلاش کن", Toast.LENGTH_SHORT).show();
                }
            });
            add(r, b, -1, 82, 12);
        }
        Button back = btn("بازگشت");
        back.setOnClickListener(v -> showMenu());
        add(r, back, -1, 76, 18);
        setContentView(r);
    }

    private void speak(String text) {
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tts1");
    }

    private void addScore(int n) {
        score += n;
        prefs.edit().putInt("score", score).apply();
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    static class LetterItem {
        String letter, word, emoji;
        LetterItem(String l, String w, String e) { letter = l; word = w; emoji = e; }
    }

    class ColoringView extends View {
        Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint drawPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        String letter;
        float lastX, lastY;
        java.util.ArrayList<float[]> lines = new java.util.ArrayList<>();
        java.util.ArrayList<Integer> colors = new java.util.ArrayList<>();
        ColoringView(Context c, String l) {
            super(c); letter = l;
            setBackgroundColor(Color.WHITE);
            textPaint.setColor(Color.rgb(230,230,230));
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(330);
            textPaint.setFakeBoldText(true);
            drawPaint.setColor(selectedColor);
            drawPaint.setStrokeWidth(28);
            drawPaint.setStrokeCap(Paint.Cap.ROUND);
        }
        void setPaintColor(int c) { drawPaint.setColor(c); }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawText(letter, getWidth()/2f, getHeight()/2f + 110, textPaint);
            Paint p = new Paint(drawPaint);
            for (int i=0; i<lines.size(); i++) {
                p.setColor(colors.get(i));
                float[] a = lines.get(i);
                canvas.drawLine(a[0], a[1], a[2], a[3], p);
            }
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction()==MotionEvent.ACTION_DOWN) { lastX=e.getX(); lastY=e.getY(); return true; }
            if (e.getAction()==MotionEvent.ACTION_MOVE) {
                lines.add(new float[]{lastX,lastY,e.getX(),e.getY()});
                colors.add(drawPaint.getColor());
                lastX=e.getX(); lastY=e.getY(); invalidate(); return true;
            }
            return true;
        }
    }
}
